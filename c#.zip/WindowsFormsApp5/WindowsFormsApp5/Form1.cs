﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] row = new string[] {"false","Ürün B","1500"};
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün B", "1500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün C", "2500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün D", "3500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün E", "4500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün F", "5500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün G", "6500" };
            dataGridView1.Rows.Add(row);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i=0; i<dataGridView1.Rows.Count;i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = false;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double top = 0;
            for (int i =0; i<dataGridView1.Rows.Count;i++)
            {
                if(Convert.ToBoolean(dataGridView1.Rows[i].Cells[0].Value)==true)
                {
                    top += double.Parse(dataGridView1.Rows[i].Cells[2].Value.ToString());
                }
            }
            textBox1.Text = top.ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
