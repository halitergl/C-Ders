﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] row = new string[] {"false","Ürün B","1500"};
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün B", "1500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün C", "2500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün D", "3500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün E", "4500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün F", "5500" };
            dataGridView1.Rows.Add(row);

            row = new string[] { "false", "Ürün G", "6500" };
            dataGridView1.Rows.Add(row);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
